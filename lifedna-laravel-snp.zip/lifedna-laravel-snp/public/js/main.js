var tbl = $("#tbl").DataTable();
var root_url = $("#root_url").val();
var url = $("#url").val();
var url_getproduct = $("#url_getproduct").val();
var list = $("#list").DataTable({ajax:url});

if(url.indexOf("products/list")!=-1){
	
	$('#list tbody').on( 'click', 'tr', function () {
        
		var d = list.row( this ).data();
		var id = d[0];
		window.location.href=root_url+"/products/edit/"+id;
		
    } );
}
