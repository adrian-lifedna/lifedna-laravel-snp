@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
			@if(Auth::guest())
              <a href="{{ route('login')}}" class="btn btn-info"> You need to login to see the list  >></a>
            @else
			<label>Products</label>
			<div class="row">	
			<form action="{{ url('/products/upload') }}" method="post" enctype="multipart/form-data">
				<!--<input type="file" name="files" class="">-->
				<label class="custom-file">
				  <input name="files" type="file" id="file" class="custom-file-input">
				  <span class="custom-file-control"></span>
				</label>
				 {{ csrf_field() }}
				<button class="btn btn-success btn-sm">Upload</button>
			</form>
			</div>
			
			 
			  <div id="tblList" class="row">
				<table class="table" id="list" style="width:100%">
					<thead>
						<tr>
							<th colspan="6"></th>
							<th colspan="3">Genotype</th>
						</tr>
						<tr>
							<th><a href="{{ url('/products/add')}}" class="btn btn-info"><i class="fa fa-plus" aria-hidden="true"></i>Add</a></th>
							<th>Product</th>
							<th>Type</th>
							<th>SNP</th>
							<th>Risk Allele</th>
							<th>Homozygous</th>
							<th>Points</th>
							<th>Heterozygous</th>
							<th>Points</th>
						</tr>
					</thead>
					<tbody>
					</tbody>
					<tfoot>
						<tr>
							<th colspan="6"></th>
							<th colspan="3">Genotype</th>
						</tr>
						<tr>
							<th>id</th>
							<th>Product</th>
							<th>Type</th>
							<th>SNP</th>
							<th>Risk Allele</th>
							<th>Homozygous</th>
							<th>Points</th>
							<th>Heterozygous</th>
							<th>Points</th>
						</tr>
					</tfoot>
				</table>
			  </div>
			 
            @endif
			
        </div>
    </div>
</div>
<input type="hidden" id="url" value="{{ url('/products/list')}}">
@endsection