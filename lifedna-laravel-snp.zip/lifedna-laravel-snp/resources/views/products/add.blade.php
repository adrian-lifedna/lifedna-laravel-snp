@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
			@if(Auth::guest())
              <a href="{{ route('login')}}" class="btn btn-info"> You need to login to see the list  >></a>
            @else
			<h3>Products</h3>
			<div class="row">
				<div class="container">
					<form method="post" action="{{ url('/products/save') }}">
						<div class="form-group">
						  <label for="usr">Product:</label>
						  <input type="text" name="product" class="form-control">
						</div>
						<div class="form-group">
						  <label for="usr">Type:</label>
						  <input type="text" name="product_type" class="form-control">
						</div>
						<div class="form-group">
						  <label for="usr">SNP:</label>
						  <input type="text" name="snp" class="form-control">
						</div>
						<div class="form-group">
						  <label for="usr">Risk Allele:</label>
						  <input type="text" name="risk_allele" class="form-control">
						</div>
						
						<div class="form-group">
						  <label for="usr">Homozygous:</label>
						  <input type="text" name="genotype_homozygous" class="form-control">
						</div>
						<div class="form-group">
						  <label for="usr">Points:</label>
						  <input type="text" name="homo_geno_points" class="form-control">
						</div>
						<div class="form-group">
						  <label for="usr">Heterozygous:</label>
						  <input type="text" name="genotype_heterozygous" class="form-control">
						</div>
						<div class="form-group">
						  <label for="usr">Points:</label>
						  <input type="text" name="hetero_geno_points" class="form-control">
						</div>
						{{ csrf_field() }}
						<button class="btn btn-success" type="submit" name="submit">Save</button>
						
						
					</form>
				</div>
			</div>
			 
            @endif
			
        </div>
    </div>
</div>
@endsection