@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
			@if(Auth::guest())
              <a href="{{ route('login')}}" class="btn btn-info"> You need to login to see the list  >></a>
            @else
            <form action="{{ url('/snp/upload') }}" method="post" enctype="multipart/form-data">
			<input type="file" name="files" >
			 {{ csrf_field() }}
			<button class="btn btn-info">Upload</button>
			</form>
            @endif
        </div>
    </div>
</div>
@endsection