@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
			@if(Auth::guest())
              <a href="{{ route('login')}}" class="btn btn-info"> You need to login to see the list  >></a>
            @else
			<div class="row">	
			<form action="{{ url('/snp/upload') }}" method="post" enctype="multipart/form-data">
				
				<label class="custom-file">
				  <input name="files" type="file" id="file" class="custom-file-input">
				  <span class="custom-file-control"></span>
				</label>
				 {{ csrf_field() }}
				<button class="btn btn-success btn-sm">Upload</button>
			</form>
			</div>
			
			<div class="row">
				 <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#tblList"><i class="fa fa-bars" aria-hidden="true"></i> Show/Hide Data</button>
				  <div id="tblList" class="collapse">
					<table class="table" id="list" style="width:100%">
						<thead>
							<tr>
								<th>RSID</th>
								<th>CHROMOSOME</th>
								<th>POSITION</th>
								<th>GENOTYPE</th>
							</tr>
						</thead>
						<tbody>
						</tbody>
						<tfoot>
							<tr>
								<th>RSID</th>
								<th>CHROMOSOME</th>
								<th>POSITION</th>
								<th>GENOTYPE</th>
							</tr>
						</tfoot>
					</table>
				  </div>
			  </div>
			  <div class="row">
				<button class="btn btn-warning" data-toggle="collapse" data-target="#pnresults"><i class="fa fa-bars" aria-hidden="true"></i> See Personalized Nutrition </button>
				<div id="pnresults" class="collapse row">
				
				<div class="container">
				
					<div class="col-md-12" id="pn_result">
					@if(isset($data['personalNutrition']['data']['supplement']))
						<div class="container">
							<div class="row">
								<span class="label label-primary">Supplement</span>
							</div>
							@foreach($data['personalNutrition']['data']['supplement'] as $product=>$list)
							<div class="row">
								<div class="col-md-4"><b>{{ $product }}</b></div>
								
							</div>
							@foreach($list as $personalNutrition)
							<div class="row">
								
								<div class="col-md-2">{{ $personalNutrition['rsid']}}</div>
								<div class="col-md-2">{{ $personalNutrition['genotype']}}</div>
								<div class="col-md-2">{{ $personalNutrition['genotype_type']}}</div>
								
								<div class="col-md-2">{{ $personalNutrition['points']}}</div>
							</div>
							@endforeach
							@endforeach
						</div>
						<div class="container">
							<div class="row">
								<span class="label label-primary">Skin Conditions</span>
							</div>
							@foreach($data['personalNutrition']['data']['skincare'] as $product=>$list)
							<div class="row">
								<div class="col-md-4"><b>{{ $product }}</b></div>
								
							</div>
							@foreach($list as $personalNutrition)
							<div class="row">
								
								<div class="col-md-2">{{ $personalNutrition['rsid']}}</div>
								<div class="col-md-2">{{ $personalNutrition['genotype']}}</div>
								<div class="col-md-2">{{ $personalNutrition['genotype_type']}}</div>
								
								<div class="col-md-2">{{ $personalNutrition['points']}}</div>
							</div>
							@endforeach
							@endforeach
						</div>
					</div>
					<div class="col-md-6" id="pn_total">
					<div class="col-md-3" >Total:</div>
					<div class="col-md-3" >{{ $data['personalNutrition']['total'] }}</div>
					@else
						<div class="container">
							<div class="row">
								<span class="label label-danger">No Data</span>
							</div>
							
						</div>
					@endif
					</div>
				</div>
				</div>
			  </div>
			  
            @endif
			
        </div>
    </div>
</div>
<input type="hidden" id="url" value="{{ url('/snp/list')}}">
<input type="hidden" id="url_getproduct" value="{{ url('/snp/getproduct')}}">
<script src="{{ asset('js/snp.js')}}"></script>
<script>
function upload_file(){
	$.ajax({
		
		
	});
	
}
</script>
@endsection