@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
			@if(Auth::guest())
              <a href="{{ route('login')}}" class="btn btn-info"> You need to login to see the list  >></a>
            @else
            <div class="panel panel-success" style="width:100%">
                <div class="panel-heading">Markers</div>

                    @if(Auth::check())
                      <!-- Table -->
                      <table class="table" id="tbl" >
						  <thead>
						  <tr>
							  <th>Accession Id</th>
							  <th>Id</th>
							  <th>Start</th>
							  <th>End</th>
							  <th>Gene Names</th>
							  <th><a href="#collapse1" data-toggle="collapse">Variants</a></th>
						  </tr>
						  </thead>
						  
						  
						  @foreach($data['markers'] as $marker)
                          <tr>
                              <td>{{ $marker->accession_id }}</td>
							  <td>{{ $marker->id }}</td>
							  <td>{{ $marker->start }}</td>
							  <td>{{ $marker->end }}</td>
							  <td>
								  <table>
									@foreach($marker->gene_names as $gene_name)
										<tr><td>{{ $gene_name }}</td></tr>
									@endforeach
								  </table>
							  </td>
							  <td>
								  <table>
									<tr>
										<th>Accession Id</th>
										<th>Start</th>
										<th>End</th>
										<th>Allele</th>
										<th>Platform Labels</th>
									</tr>
									<tbody id="collapse1" class="panel-collapse collapse">	
									@foreach($marker->variants as $variant)
										<tr>
											<td>{{ $variant->accession_id }}</td>
											<td>{{ $variant->start }}</td>
											<td>{{ $variant->end }}</td>
											<td>{{ $variant->allele }}</td>
											<td>
												<table>
												@foreach($variant->platform_labels as $platform_label)
												<tr><td>{{ $platform_label }}</td></tr>
												@endforeach
												</table>
											</td>
										</tr>
									@endforeach
								  </table>
								  </tbody>	
							  </td>
                          </tr>
                          @endforeach
						  
                      </table>
                    @endif


            </div>
            @endif
        </div>
    </div>
</div>
@endsection