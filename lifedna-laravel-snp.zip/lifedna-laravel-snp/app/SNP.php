<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SNP extends Model
{
    //
	protected $table='snp';
	protected $fillable = [
        'user_id', 'rsid', 'chromosome','position','genotype'
    ];
	public function getDataByUserId($user_id){
		$list = self::where('user_id',$user_id)->get();
		return $list;
	}
}
