<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Products;

class productController extends Controller
{
    //
	public function index(){
		
		return view("products.index");
	}
	public function getList(){
		
		$list = Products::get();
		$arr = array();
		foreach($list as $l):
			$arr[] = array($l['id'],
						   $l["product"],
						   $l["product_type"],
						   $l["snp"],
						   $l["risk_allele"],
						   $l["genotype_homozygous"],
						   $l["homo_geno_points"],
						   $l["genotype_heterozygous"],
						   $l["hetero_geno_points"]
						   );
		endforeach;
		
		return response()->json(array("data"=>$arr));
	}
	public function upload(Request $request){
				
		if($request->file('files')!=null){
			try
			{
				$contents = file($request->file('files'));
				$x=0;
				foreach($contents as $content):
					
					if(trim($content)!=''):
														
							list($product,$snp,$risk_allele,$gen_homo,$gen_hetero,$type) = explode(",",trim($content));
														
							ini_set('MAX_EXECUTION_TIME', -1);
							set_time_limit('1000');
							$homo_geno = "";
							$homo_point = "";
							$hetero_geno = "";
							$hetero_point = "";
							
							if(isset($gen_homo)):
								if(preg_match('/\s/',$gen_homo)!=0)://check if there is whitespace
									list($homo_geno,$homo_point) = explode(" ",trim($gen_homo));
								endif;
							endif;
							
							if(isset($gen_hetero)):
								if(preg_match('/\s/',$gen_hetero)!=0): //check if there is whitespace
									list($hetero_geno,$hetero_point) = explode(" ",$gen_hetero);
								endif;
							endif;
														
							$products = new Products();
							$products->product = $product;
							$products->product_type = $type;
							$products->snp = $snp;
						    $products->risk_allele= $risk_allele;
						    $products->genotype_homozygous = $homo_geno;
							$products->genotype_heterozygous = $hetero_geno;
							$products->homo_geno_points = $homo_point;
							$products->hetero_geno_points = $hetero_point;
							$products->save();
							
					endif;
					$x++;
				endforeach;
				
			}
			catch (Illuminate\Filesystem\FileNotFoundException $exception)
			{
				die("The file doesn't exist");
			}
			
		}
		return redirect("/products");
	}
	public function save(Request $request){
		ini_set('memory_limit', '-1');		
		ini_set('MAX_EXECUTION_TIME', -1);
		set_time_limit('1000');
		$products = new Products;
		
		$products->product = $request->product;
		$products->product_type = $request->product_type;
		$products->snp = $request->snp;
		$products->risk_allele = $request->risk_allele;
		$products->genotype_homozygous = $request->genotype_homozygous;
		$products->genotype_heterozygous = $request->genotype_heterozygous;
		$products->homo_geno_points = $request->homo_geno_points;
		$products->hetero_geno_points = $request->hetero_geno_points;
		$products->save();
		return redirect('/products');
	}
	public function update(Request $request,$id){
		$products = Products::find($id);
		$products->product = $request->product;
		$products->product_type = $request->product_type;
		$products->snp = $request->snp;
		$products->risk_allele = $request->risk_allele;
		$products->genotype_homozygous = $request->genotype_homozygous;
		$products->genotype_heterozygous = $request->genotype_heterozygous;
		$products->homo_geno_points = $request->homo_geno_points;
		$products->hetero_geno_points = $request->hetero_geno_points;
		$products->save();
		return redirect('/products');
	}
	public function add(){
		
		return view("products.add");
	}
	public function edit($id){
		$products = Products::find($id);
		return view("products.edit")->with("data",$products);
	}
	public function destroy($id) {
	  $products = Products::find($id);
	  $products->delete();

	  return redirect('/products');
	}
}