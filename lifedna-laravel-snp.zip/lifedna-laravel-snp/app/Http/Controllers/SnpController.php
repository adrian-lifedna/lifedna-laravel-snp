<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use File;
use Auth;
use DB;
use App\SNP;
use App\Products;
class SnpController extends Controller
{
    //
	public function index(){
		$user_id = Auth::user()->id;
		$personalNutrition = $this->getProductList();
		
						//print_r($personalNutrition);
		return view('snp.index')->with("data",array("personalNutrition"=>$personalNutrition));
	}
	public function getList(){
		ini_set('memory_limit', '2048M');
		$user_id = Auth::user()->id;
		$list = SNP::select('products.*',
							'snp.*'
							)
					->join('products','products.snp','=','snp.rsid')
					->where('user_id',$user_id)
					->get();
		//$list = SNP::where('user_id',$user_id)->paginate(300);
		$arr = array();
		foreach($list as $l):
			$arr[] = array($l["rsid"],
						   $l["chromosome"],
						   $l["position"],
						   $l["genotype"]);
		endforeach;
		
		return response()->json(array("data"=>$arr));
	}
	public function store(Request $request){
		
		$user_id = Auth::user()->id;
		$file = $request->file('files');
		$table = 'snp';
		$fileName = $file->getClientOriginalName();
		if($request->file('files')!=null){
			try
			{
				ini_set('MAX_EXECUTION_TIME', -1);
				set_time_limit('1000');
				ini_set('memory_limit', '96M');
				ini_set('post_max_size', '105M');
				ini_set('upload_max_filesize', '150M');
				
				$file->move("uploads",$file->getClientOriginalName());
				$filename = public_path()."/uploads/".$file->getClientOriginalName();
				 return ( $this->_import_snp($filename,$user_id) ? redirect('/snp') : 'No Rows Affected'); 
				
				
			}
			catch (Illuminate\Filesystem\FileNotFoundException $exception)
			{
				die("The file doesn't exist");
			}
			
		}
		//return view('snp.upload');
	}
	public function upload(Request $request){
		
		$user_id = Auth::user()->id;
		$file = $request->file('files');
		$table = 'snp';
		$fileName = $file->getClientOriginalName();
		if($request->file('files')!=null){
			try
			{
				ini_set('MAX_EXECUTION_TIME', -1);
				set_time_limit('1000');
				ini_set('memory_limit', '96M');
				ini_set('post_max_size', '105M');
				ini_set('upload_max_filesize', '150M');
				
				$file->move("uploads",$file->getClientOriginalName());
				$filename = public_path()."/uploads/".$file->getClientOriginalName();
				 return ( $this->_import_snp($filename,$user_id) ? "Ok" :"Error"); 
				
				
			}
			catch (Illuminate\Filesystem\FileNotFoundException $exception)
			{
				die("The file doesn't exist");
			}
			
		}
	
	}
	public function _import_snp($filename,$user_id){
	
		$query = sprintf("LOAD DATA LOCAL INFILE '%s'
								INTO TABLE snp
								FIELDS TERMINATED by \"\t\"
								LINES TERMINATED BY \"\n\"
								IGNORE 20 LINES
								(rsid,chromosome,position,genotype) set user_id='%d'",addslashes($filename),$user_id);
		 $res = DB::connection()->getpdo()->exec($query);
		 File::delete($filename);
		return $res;
	}
	public function getProduct(){
		$user_id = Auth::user()->id;
		$lists = SNP::where('user_id',$user_id)->get();
			
		$personalized_nutrition = array();
		$personalized_nutrition['supplement'] = array();
		$personalized_nutrition['skincare'] = array();
		foreach($lists as $list):
		$rsid 	  = $list->rsid; 
		$genotype = $list->genotype;
	
		$products = Products::where("snp",$rsid)->get();
				
		if(count($products)>0){
			foreach($products as $product):
				if($genotype==$product->genotype_homozygous):
					$personalized_nutrition[$product->product] = array("type"=>$product->product_type,
																	   "points"=>$product->homo_geno_points);
				endif;
				if($genotype==$product->genotype_heterozygous):
					$personalized_nutrition[$product->product] = array("type"=>$product->product_type,
																	 "points"=>$product->hetero_geno_points);
				endif;
			endforeach;	
			
		}
		endforeach;
		$pn = array();
		$pn_supplement = array();
		$pn_skincare = array();
		$total = 0;
		foreach($personalized_nutrition as $key=>$val): 
		if($val['type']=='supplement'):
			$pn_supplement[] = array("product"=>$key,"points"=>$val['points'],"type"=>$val['type']); 
		else:
			$pn_skincare[] = array("product"=>$key,"points"=>$val['points'],"type"=>$val['type']); 
		endif;
		$total +=$val['points']; 
		endforeach;
		
		arsort($pn_supplement);
		arsort($pn_skincare);
		
		$pn['supplement'] = $pn_supplement;
		$pn['skincare'] = $pn_skincare;
		return response()->json(array("data"=>$pn,"total"=>$total));
	}
	public function getProductList(){
		$user_id = Auth::user()->id;
				
		$lists = SNP::select('products.*',
							'snp.*'
							)
					->join('products','products.snp','=','snp.rsid')
					->where('user_id',$user_id)
					->get();
						
		$pn = array();
		$total = 0;
		$total_supplements = 0;
		$total_skincare = 0;
		if(count($lists)>0){
		$personalized_nutrition = array();
		$skincare = array();
		$supplements = array();
		foreach($lists as $list):
		$rsid 	  = $list->rsid;
		$genotype = $list->genotype;
		$products = Products::where("snp",$rsid)->get();
		
		if(count($products)>0):
			foreach($products as $product):
			$prod = "";
			$points = 0;
				if(trim($genotype)==trim($product->genotype_homozygous)):
				
					$personalized_nutrition[$rsid]=array("product"=>$product->product, 
													"rsid"=>$rsid,
													"type"=>$product->product_type,
													"points"=>$product->homo_geno_points,
													"genotype"=>$genotype,
													"genotype_type"=>"HOMOZYGOUS");
				endif;
				
				if(trim($genotype)==trim($product->genotype_heterozygous)):
				
					$personalized_nutrition[$rsid] = array("product"=>$product->product, 
													  "rsid"=>$rsid,
													  "type"=>$product->product_type,
													  "points"=>$product->hetero_geno_points,
													  "genotype"=>$genotype,
													  "genotype_type"=>"HETEROZYGOUS");
				endif;
				
			endforeach;	
			
		endif;
		endforeach;
				//print_r($personalized_nutrition);
		foreach($personalized_nutrition as $key=>$val): 
		if($val['type']=='supplement'): $supplements[] = array("rsid"=>$val['rsid'],
															  "product"=>$val['product'],
															  "points"=>$val['points'],
															  "genotype"=>$val['genotype'],
															  "genotype_type"=>$val['genotype_type']); 
		else: $skincare[] = array("rsid"=>$val['rsid'],
		                          "product"=>$val['product'],
								  "points"=>$val['points'],
								  "genotype"=>$val['genotype'], 
								  "genotype_type"=>$val['genotype_type']); 
		//$total +=$val['points']; 
		endif;
		endforeach;
		
		$splmt = array();
		$sc = array();
		
		if(count($supplements)>0):
			usort($supplements,function($a,$b){ return strcmp($a['product'],$b['product']); });
			usort($supplements,function($a,$b){
				if ($a['points'] == $b['points']) return 0;
				return $b['points'] > $a['points'] ? 1 : -1;
			});
			//foreach($supplements as $val){ $splmt[$val['product']] = $val;}
			//$supplements = $splmt;
			/*
			usort($supplements,function($a,$b){
				if ($a['points'] == $b['points']) return 0;
				return $b['points'] > $a['points'] ? 1 : -1;
			});
			*/
		endif;
		
		if(count($skincare)>0):
			usort($skincare,function($a,$b){ return strcmp($a['product'],$b['product']); });
			usort($skincare,function($a,$b){
				if ($a['points'] == $b['points']) return 0;
				return $b['points'] > $a['points'] ? 1 : -1;
			});
			
			//foreach($skincare as $val){ $sc[$val['product']] = $val;}
		//	$skincare = $sc;
		/*
			usort($skincare,function($a,$b){
				if ($a['points'] == $b['points']) return 0;
				return $b['points'] > $a['points'] ? 1 : -1;
			});
			*/
		endif;
		
		$supp = array();
		$skin = array();
		foreach($supplements as $val):
		$supp[$val['product']][] = array("rsid"=>$val['rsid'],
									   "product"=>$val['product'],
									   "points"=>$val['points'],
									   "genotype"=>$val['genotype'],
									   "genotype_type"=>$val['genotype_type']
		
		);
		endforeach;
		foreach($skincare as $val):
		$skin[$val['product']][] = array("rsid"=>$val['rsid'],
									   "product"=>$val['product'],
									   "points"=>$val['points'],
									   "genotype"=>$val['genotype'],
									   "genotype_type"=>$val['genotype_type']
		
		);
		endforeach;
		//print_r(count($supp));
		$supplements = $supp;
		$skincare = $skin;
		
		
		$x=1;
		$supps = array();
		foreach($supplements as $product=>$supplement):
		if($x<6): 
			$supps[$product] = $supplement; 
			foreach($supplement as $supp):
			$total_supplements +=$supp['points']; 
			endforeach;
		endif;
		$x++;
		endforeach;
		
		$supplements = $supps;
		
		$y=1;
		$skins = array();
		foreach($skincare as $product=>$sc):
		if($y<3): 
			$skins[$product] = $sc; 
			foreach($sc as $skin):
			$total_skincare +=$skin['points'];
			endforeach;
		endif;
		$y++;
		endforeach;
		$skincare = $skins;
		
		
		$pn['supplement']=$supplements;
		$pn['skincare']=$skincare;
		}
		$total = $total_supplements+$total_skincare;
		return array("data"=>$pn,"total"=>$total);
	}	
	
}
