<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Crypt;
use SNP;
class DNAController extends Controller
{
    //
	/**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        				
		$ch = curl_init();
		$client_id = '3b79c25d53a62c3a60ef32a69a1cc868';
		$client_secret = 'ada3f3bb8263b0a24382c304688c46cc';
		$vars = "client_id=".$client_id."&client_secret=".$client_secret;		  
		curl_setopt($ch, CURLOPT_URL,"https://api.23andme.com/3/marker/?gene_name=ACTN3&".$vars);
		//curl_setopt($ch, CURLOPT_POST, 1);
		//curl_setopt($ch, CURLOPT_POSTFIELDS,$vars);  //Post Fields
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$headers = [
			'Authorization: Bearer demo_oauth_token',
		];
		
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$server_output = curl_exec ($ch);
		$info = curl_getinfo($ch);
		curl_close ($ch);
		//print_r($info);
		$data = json_decode($server_output);
		//$encrypted = Crypt::encryptString('Hello world.');
		//$decrypted = Crypt::decryptString($encrypted);
	//echo "<pre>";
	//print_r($data->data[0]);
		return view('dna')->with("data",array("markers"=>$data->data,"curl_info"=>$info));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }
	
    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store()
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        //
		
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update($id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }

}
