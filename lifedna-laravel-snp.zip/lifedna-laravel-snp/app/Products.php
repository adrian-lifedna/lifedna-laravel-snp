<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Products extends Model
{
    //
	protected $table='products';
	protected $fillable = [
        'product', 'product_type', 'snp','risk_allele','genotype_heteroxygous','genotype_homozygous','homo_geno_points','hetero_geno_points'
    ];
}
