<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
			<?php if(Auth::guest()): ?>
              <a href="<?php echo e(route('login')); ?>" class="btn btn-info"> You need to login to see the list  >></a>
            <?php else: ?>
            <div class="panel panel-success" style="width:100%">
                <div class="panel-heading">Markers</div>

                    <?php if(Auth::check()): ?>
                      <!-- Table -->
                      <table class="table" id="tbl" >
						  <thead>
						  <tr>
							  <th>Accession Id</th>
							  <th>Id</th>
							  <th>Start</th>
							  <th>End</th>
							  <th>Gene Names</th>
							  <th><a href="#collapse1" data-toggle="collapse">Variants</a></th>
						  </tr>
						  </thead>
						  
						  
						  <?php $__currentLoopData = $data['markers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($marker->accession_id); ?></td>
							  <td><?php echo e($marker->id); ?></td>
							  <td><?php echo e($marker->start); ?></td>
							  <td><?php echo e($marker->end); ?></td>
							  <td>
								  <table>
									<?php $__currentLoopData = $marker->gene_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gene_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr><td><?php echo e($gene_name); ?></td></tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								  </table>
							  </td>
							  <td>
								  <table>
									<tr>
										<th>Accession Id</th>
										<th>Start</th>
										<th>End</th>
										<th>Allele</th>
										<th>Platform Labels</th>
									</tr>
									<tbody id="collapse1" class="panel-collapse collapse">	
									<?php $__currentLoopData = $marker->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><?php echo e($variant->accession_id); ?></td>
											<td><?php echo e($variant->start); ?></td>
											<td><?php echo e($variant->end); ?></td>
											<td><?php echo e($variant->allele); ?></td>
											<td>
												<table>
												<?php $__currentLoopData = $variant->platform_labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform_label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<tr><td><?php echo e($platform_label); ?></td></tr>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</table>
											</td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								  </table>
								  </tbody>	
							  </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						  
                      </table>
                    <?php endif; ?>


            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>