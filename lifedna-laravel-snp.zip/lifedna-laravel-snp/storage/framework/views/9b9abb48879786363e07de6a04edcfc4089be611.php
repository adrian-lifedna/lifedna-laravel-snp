<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
			<?php if(Auth::guest()): ?>
              <a href="<?php echo e(route('login')); ?>" class="btn btn-info"> You need to login to see the list  >></a>
            <?php else: ?>
            <form action="<?php echo e(url('/snp/upload')); ?>" method="post" enctype="multipart/form-data">
			<input type="file" name="files" >
			 <?php echo e(csrf_field()); ?>

			<button class="btn btn-info">Upload</button>
			</form>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>