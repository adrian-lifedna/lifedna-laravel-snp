<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
			<?php if(Auth::guest()): ?>
              <a href="<?php echo e(route('login')); ?>" class="btn btn-info"> You need to login to see the list  >></a>
            <?php else: ?>
			<div class="row">	
			<form action="<?php echo e(url('/snp/upload')); ?>" method="post" enctype="multipart/form-data">
				
				<label class="custom-file">
				  <input name="files" type="file" id="file" class="custom-file-input">
				  <span class="custom-file-control"></span>
				</label>
				 <?php echo e(csrf_field()); ?>

				<button class="btn btn-success btn-sm">Upload</button>
			</form>
			</div>
			
			<div class="row">
				 <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#tblList"><i class="fa fa-bars" aria-hidden="true"></i> Show/Hide Data</button>
				  <div id="tblList" class="collapse">
					<table class="table" id="list" style="width:100%">
						<thead>
							<tr>
								<th>RSID</th>
								<th>CHROMOSOME</th>
								<th>POSITION</th>
								<th>GENOTYPE</th>
							</tr>
						</thead>
						<tbody>
						</tbody>
						<tfoot>
							<tr>
								<th>RSID</th>
								<th>CHROMOSOME</th>
								<th>POSITION</th>
								<th>GENOTYPE</th>
							</tr>
						</tfoot>
					</table>
				  </div>
			  </div>
			  <div class="row">
				<button class="btn btn-warning" data-toggle="collapse" data-target="#pnresults"><i class="fa fa-bars" aria-hidden="true"></i> See Personalized Nutrition </button>
				<div id="pnresults" class="collapse row">
				
				<div class="container">
				
					<div class="col-md-12" id="pn_result">
					<?php if(isset($data['personalNutrition']['data']['supplement'])): ?>
						<div class="container">
							<div class="row">
								<span class="label label-primary">Supplement</span>
							</div>
							<?php $__currentLoopData = $data['personalNutrition']['data']['supplement']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product=>$list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="row">
								<div class="col-md-4"><b><?php echo e($product); ?></b></div>
								
							</div>
							<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personalNutrition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="row">
								
								<div class="col-md-2"><?php echo e($personalNutrition['rsid']); ?></div>
								<div class="col-md-2"><?php echo e($personalNutrition['genotype']); ?></div>
								<div class="col-md-2"><?php echo e($personalNutrition['genotype_type']); ?></div>
								
								<div class="col-md-2"><?php echo e($personalNutrition['points']); ?></div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<div class="container">
							<div class="row">
								<span class="label label-primary">Skin Conditions</span>
							</div>
							<?php $__currentLoopData = $data['personalNutrition']['data']['skincare']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product=>$list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="row">
								<div class="col-md-4"><b><?php echo e($product); ?></b></div>
								
							</div>
							<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personalNutrition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="row">
								
								<div class="col-md-2"><?php echo e($personalNutrition['rsid']); ?></div>
								<div class="col-md-2"><?php echo e($personalNutrition['genotype']); ?></div>
								<div class="col-md-2"><?php echo e($personalNutrition['genotype_type']); ?></div>
								
								<div class="col-md-2"><?php echo e($personalNutrition['points']); ?></div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
					<div class="col-md-6" id="pn_total">
					<div class="col-md-3" >Total:</div>
					<div class="col-md-3" ><?php echo e($data['personalNutrition']['total']); ?></div>
					<?php else: ?>
						<div class="container">
							<div class="row">
								<span class="label label-danger">No Data</span>
							</div>
							
						</div>
					<?php endif; ?>
					</div>
				</div>
				</div>
			  </div>
			  
            <?php endif; ?>
			
        </div>
    </div>
</div>
<input type="hidden" id="url" value="<?php echo e(url('/snp/list')); ?>">
<input type="hidden" id="url_getproduct" value="<?php echo e(url('/snp/getproduct')); ?>">
<script src="<?php echo e(asset('js/snp.js')); ?>"></script>
<script>
function upload_file(){
	$.ajax({
		
		
	});
	
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>