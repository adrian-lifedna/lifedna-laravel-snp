<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
			<?php if(Auth::guest()): ?>
              <a href="<?php echo e(route('login')); ?>" class="btn btn-info"> You need to login to see the list  >></a>
            <?php else: ?>
			<label>Products</label>
			<div class="row">	
			<form action="<?php echo e(url('/products/upload')); ?>" method="post" enctype="multipart/form-data">
				<!--<input type="file" name="files" class="">-->
				<label class="custom-file">
				  <input name="files" type="file" id="file" class="custom-file-input">
				  <span class="custom-file-control"></span>
				</label>
				 <?php echo e(csrf_field()); ?>

				<button class="btn btn-success btn-sm">Upload</button>
			</form>
			</div>
			
			 
			  <div id="tblList" class="row">
				<table class="table" id="list" style="width:100%">
					<thead>
						<tr>
							<th colspan="6"></th>
							<th colspan="3">Genotype</th>
						</tr>
						<tr>
							<th><a href="<?php echo e(url('/products/add')); ?>" class="btn btn-info"><i class="fa fa-plus" aria-hidden="true"></i>Add</a></th>
							<th>Product</th>
							<th>Type</th>
							<th>SNP</th>
							<th>Risk Allele</th>
							<th>Homozygous</th>
							<th>Points</th>
							<th>Heterozygous</th>
							<th>Points</th>
						</tr>
					</thead>
					<tbody>
					</tbody>
					<tfoot>
						<tr>
							<th colspan="6"></th>
							<th colspan="3">Genotype</th>
						</tr>
						<tr>
							<th>id</th>
							<th>Product</th>
							<th>Type</th>
							<th>SNP</th>
							<th>Risk Allele</th>
							<th>Homozygous</th>
							<th>Points</th>
							<th>Heterozygous</th>
							<th>Points</th>
						</tr>
					</tfoot>
				</table>
			  </div>
			 
            <?php endif; ?>
			
        </div>
    </div>
</div>
<input type="hidden" id="url" value="<?php echo e(url('/products/list')); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>