<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::resource('dna','DNAController');
Route::get('profile', 'UserController@profile');
Route::get('/snp', 'SnpController@index');
Route::post('/snp/upload', 'SnpController@store');
Route::get('/snp/uploader', 'SnpController@upload');
Route::get('/snp/list', 'SnpController@getList');
Route::get('/snp/getproduct', 'SnpController@getProduct');
Route::get('/products','productController@index');
Route::post('/products/upload','ProductController@upload');
Route::get('/products/list','ProductController@getList');
Route::get('/products/add','ProductController@add');
Route::get('/products/edit/{id}','ProductController@edit');
Route::delete('/products/delete/{id}','ProductController@destroy');
Route::post('/products/save','ProductController@save');
Route::post('/products/update/{id}','ProductController@update');
Route::post('profile', 'UserController@update_avatar');

use Oseintow\Shopify\Facades\Shopify;

Route::get("install_shop",function()
{
    $shopUrl = "game-store-and-beyond.myshopify.com";
    $scope = ["write_products","read_orders"];
    $redirectUrl = "http://mydomain.com/process_shopify_data";

    $shopify = Shopify::setShopUrl($shopUrl);
    return redirect()->to($shopify->getAuthorizeUrl($scope,$redirectUrl));
});
